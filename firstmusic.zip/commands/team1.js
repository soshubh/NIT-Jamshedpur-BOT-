const { MessageEmbed } = require("discord.js");
const i18n = require("../util/i18n");
module.exports = {
  name: "team1",
  aliases: ["t1"],
  description: i18n.__("team1.description"),
  execute(message) {
    let commands = message.client.commands.array();
    
  
    // let team1Embed = new MessageEmbed()
    //   .setTitle(i18n.__mf("team1.embedTitle", { botname: message.client.user.username }))
    //   .setDescription(i18n.__("team1.embedDescription"))
    //   .setColor("#ff00ff");

    // commands.forEach((cmd) => {
    //   team1Embed.addField(
    //     `**${message.client.prefix}${cmd.name} ${cmd.aliases ? `(${cmd.aliases})` : ""}**`,
    //     `${cmd.description}`,
    //     true
    //   );
    // }
    // );

    // team1Embed.setTimestamp();

    // return message.channel.send(team1Embed).catch(console.error);
   return message.channel.send('https://media.discordapp.net/attachments/947842816833364038/947846975619997726/IMG-20220228-WA0031.jpg').then(msg => setTimeout(() => msg.delete(), 20000));
  }
};